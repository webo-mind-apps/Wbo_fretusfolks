<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['protocol']     = 'smtp';
$config['smtp_host']    = 'webomindapps.co.in';
$config['smtp_port']    = 587;
$config['smtp_user']    = 'no-reply@webomindapps.co.in';
$config['smtp_pass']    = '0CPFFCKNGV9U';
$config['smtp_crypto']  = 'tls';
$config['mailtype']     = 'html';
$config['charset']      = 'iso-8859-1';
$config['wordwrap']     = TRUE;
