<?php defined('BASEPATH') or exit('No direct script access allowed');

$config['iteration_count'] = 10;
$config['portable_hashes'] = FALSE;

/* End of file bcrypt.php */
/* Location: ./system/application/config/bcrypt.php */