<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['protocol']     = 'smtp';
$config['smtp_host']    = 'mail.fretusfolks.com';
$config['smtp_port']    = 587;
$config['smtp_user']    = 'no-reply@fretusfolks.com';
$config['smtp_pass']    = 'l_dJHG@HKaW+';
$config['smtp_crypto']  = 'tls';
$config['mailtype']     = 'html';
$config['charset']      = 'iso-8859-1';
$config['wordwrap']     = TRUE;
